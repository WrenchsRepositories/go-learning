# 新手教程：用 Go 写一个 Windows 国际象棋程序

> 目标读者：有 Go 基础（知道 struct、method、slice、map、package），想从零写一个完整桌面 GUI 应用的新手。
> 最终产出：一个约 48MB 的 `chess.exe`，支持双人本地对弈，含完整国际象棋规则。

---

## 0. 先看效果

你将做出这样一个程序：

- 8×8 标准棋盘，带 a–h 列号和 1–8 行号
- 点击己方棋子 → 绿色高亮可走位置、红色高亮可吃子
- 黄色高亮当前选中、深黄高亮上一步
- 将军时王被红色高亮，将死/逼和/和棋会判定并显示
- 兵走到底线弹出「升变」对话框（后/车/象/马）
- 王车易位、吃过路兵都支持
- 侧栏有「当前回合 / 游戏状态 / 新游戏 / 帮助」

---

## 1. 准备工作

### 1.1 安装 Go

Windows 下到 <https://go.dev/dl/> 下载 `go1.22.x.windows-amd64.msi`，双击安装，默认选项即可。然后打开 PowerShell 验证：

```powershell
go version
# 应输出类似：go version go1.22.5 windows/amd64
```

### 1.2 选一个 Go GUI 框架

Go 做桌面 GUI 主流有 3 个选择，新手**推荐 Fyne**：

| 框架 | 优点 | 缺点 |
|------|------|------|
| **Fyne** ✅ | 纯 Go、跨平台、文档清晰、组件齐全、`go build` 直接出 exe | 二进制偏大（~50MB） |
| Walk (Win32) | 体积小、原生 Windows 外观 | 只支持 Windows、API 较老、维护少 |
| Gio | 现代、轻量 | 组件较少、需要对 immediate mode UI 有理解 |

本教程用 **Fyne v2**。

### 1.3 创建项目目录

```powershell
mkdir C:\Users\你\Desktop\chess
cd C:\Users\你\Desktop\chess
go mod init chess
```

然后拉 Fyne 依赖（首次下载需等待一会儿）：

```powershell
go get fyne.io/fyne/v2@latest
go mod tidy
```

> 💡 小提示：Fyne 依赖很多子包（OpenGL、字体渲染等），第一次 `go mod tidy` 会下 30+ 个包，**耐心等它完成**。

---

## 2. 项目设计：先写「引擎」再写「界面」

初学者最容易犯的错误是：把棋盘绘制和走子规则混在一块，改一个 bug 就牵一发动全身。

**正确分层**：

```
chess/
├── engine/          ← 规则引擎（纯逻辑，不碰 GUI）
│   ├── chess.go
│   └── chess_test.go
├── main.go          ← Fyne GUI（只调用 engine 的 API）
└── go.mod
```

核心原则：**engine 不 import GUI，GUI 只调用 engine 的公开方法**。
这样你可以用 `go test` 直接测规则，不用启动窗口。

---

## 3. 第一步：写规则引擎 engine/chess.go

### 3.1 定义基础类型

先把「颜色、棋子种类、格子、走子、游戏状态」这几个概念用 Go 的类型表达出来。

```go
// engine/chess.go
package engine

type Color int8
const (
    White Color = 1
    Black Color = -1
)

type PieceType int8
const (
    NoType PieceType = iota  // 空格
    Pawn                     // 兵
    Knight                   // 马
    Bishop                   // 象
    Rook                     // 车
    Queen                    // 后
    King                     // 王
)

type Piece struct {
    Type  PieceType
    Color Color
}
var NoPiece = Piece{}

type Square struct {
    Row, Col int  // Row: 0 是黑方底线，7 是白方底线；Col: 0=a, 7=h
}

type Move struct {
    From        Square
    To          Square
    Captured    PieceType   // 吃掉的子（NoType 表示没吃）
    PromotedTo  PieceType   // 兵升变成什么（NoType 表示不升变）
    IsCastle    bool        // 是否为王车易位
    IsEnPassant bool        // 是否为吃过路兵
}

type GameState struct {
    Board          [8][8]Piece
    Turn           Color           // 当前谁走
    CastlingRights [4]bool         // 王车易位权：[WK, WQ, BK, BQ]
    EnPassant      *Square         // 当前可吃过路兵的目标格，nil 表示没有
    HalfMoveClock  int             // 50 回合规则计数（半回合）
    FullMoveNumber int             // 完整回合数
    History        []Move          // 历史走子
}
```

> 💡 新手小技巧：先别写具体实现，先「把脑子里的概念翻译成类型」，编译通过再填函数。

### 3.2 初始化开局

```go
func NewGame() *GameState {
    g := &GameState{
        Turn:           White,
        CastlingRights: [4]bool{true, true, true, true},
        FullMoveNumber: 1,
    }
    g.setupInitialPosition()
    return g
}

func (g *GameState) setupInitialPosition() {
    backRank := []PieceType{Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook}
    for col := 0; col < 8; col++ {
        g.Board[0][col] = Piece{Type: backRank[col], Color: Black}
        g.Board[1][col] = Piece{Type: Pawn, Color: Black}
        g.Board[6][col] = Piece{Type: Pawn, Color: White}
        g.Board[7][col] = Piece{Type: backRank[col], Color: White}
    }
}
```

### 3.3 合法走子生成（最重要的函数）

国际象棋规则校验的**业界标准流程**：

1. **伪合法走法**（pseudo-legal）：只考虑「棋子本身怎么走」，不考虑「走完会不会把自己王送掉」
2. **逐一应用** → **检测己方王是否被将军** → 不合法就丢弃
3. 剩下的就是**合法走子**（legal）

```go
func (g *GameState) GenerateLegalMoves(from Square) []Move {
    p := g.PieceAt(from)
    if p.Type == NoType || p.Color != g.Turn {
        return nil
    }
    pseudo := g.generatePseudoMoves(from, p)
    legal := make([]Move, 0, len(pseudo))
    for _, m := range pseudo {
        ng := g.clone()         // 克隆局面
        ng.makeMove(m)          // 在克隆局面上应用
        if !ng.isKingInCheck(p.Color) {
            legal = append(legal, m)
        }
    }
    return legal
}
```

为什么要**克隆局面**再试？因为这样写逻辑最简单：
- 不担心「回滚不完整」这种隐蔽 bug
- 8×8 棋盘才 64 格，复制 1000 次都感知不到延迟

### 3.4 各种棋子的伪合法走法

6 种棋子各写一个小函数，写起来非常机械：

```go
func (g *GameState) knightMoves(from Square, p Piece) []Move {
    var moves []Move
    // 马有 8 个 L 形方向
    offsets := [][2]int{{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}}
    for _, o := range offsets {
        to := Square{from.Row + o[0], from.Col + o[1]}
        if !to.IsValid() { continue }
        target := g.PieceAt(to)
        if target.Type == NoType {
            moves = append(moves, Move{From: from, To: to})
        } else if target.Color != p.Color {
            moves = append(moves, Move{From: from, To: to, Captured: target.Type})
        }
    }
    return moves
}

// 象/车/后 是「滑行棋子」，写法完全一样，只是方向数组不同
func (g *GameState) slidingMoves(from Square, p Piece, dirs [][2]int) []Move {
    var moves []Move
    for _, d := range dirs {
        for i := 1; i < 8; i++ {
            to := Square{from.Row + d[0]*i, from.Col + d[1]*i}
            if !to.IsValid() { break }
            target := g.PieceAt(to)
            if target.Type == NoType {
                moves = append(moves, Move{From: from, To: to})
            } else {
                if target.Color != p.Color {
                    moves = append(moves, Move{From: from, To: to, Captured: target.Type})
                }
                break   // 被挡住，不能再滑
            }
        }
    }
    return moves
}
```

兵的规则最啰嗦（前进、吃子、初动 2 格、升变、吃过路兵），但**写清楚每个分支**就行，代码参考项目里的 `pawnMoves`，注释都有。

### 3.5 关键：某格是否被对方攻击

将军、合法走子过滤、王车易位穿越判定 —— 这 3 件事都要用到「某格是否被对手 attack」这个函数。**一定要把它写对！**

```go
func (g *GameState) isSquareAttacked(sq Square, by Color) bool {
    // 1. 对方的兵能否攻击到此格（注意兵的方向是斜向！）
    //    白兵 (r, c) 攻击 (r-1, c±1)，所以反过来：如果攻击方是白方，
    //    那么在 sq.Row+1 行找同颜色的兵
    pawnSrcRow := sq.Row + 1
    if by == Black { pawnSrcRow = sq.Row - 1 }
    for _, dc := range []int{-1, 1} {
        ps := Square{pawnSrcRow, sq.Col - dc}
        if ps.IsValid() && g.PieceAt(ps).Type == Pawn && g.PieceAt(ps).Color == by {
            return true
        }
    }
    // 2. 马 8 个方向
    // 3. 王 8 个方向
    // 4. 象/后 斜 4 个方向（滑行）
    // 5. 车/后 直 4 个方向（滑行）
    // ... 具体代码见项目文件
    return false
}
```

> ⚠️ 新手最容易错的就是「兵攻击方向」。**写单元测试逮它**！

### 3.6 应用走子 + 更新游戏状态

`makeMove` 做以下几件事，按顺序别漏：
1. 把 Piece 从 From 搬到 To
2. 如果是吃过路兵 → 额外把对面前行的兵删掉
3. 如果是王车易位 → 把对应车也搬过去
4. 如果是升变 → 把 To 格子的棋子换成升变目标
5. 更新易位权（王动过、车动过、车被吃）
6. 设置/清除 EnPassant 目标格
7. 半回合计数（兵动或吃子归零）、回合计数、切换行棋方

---

## 4. 第二步：写单元测试验证引擎

**这一步新手最容易跳过，然后在 GUI 层调试半天找不到 bug。**

在 `engine/chess_test.go` 里写几个简单测试，`go test ./engine/ -v` 立刻能知道哪里错了：

```go
// engine/chess_test.go
package engine
import "testing"

func TestLegalMovesCount(t *testing.T) {
    g := NewGame()
    moves := g.GenerateAllLegalMoves()
    // 国际象棋开局：白方恰有 20 步合法走法（16 步兵 + 马的 4 步）
    if len(moves) != 20 {
        t.Errorf("开局应有 20 步，算出来 %d 步，走子生成一定有 bug", len(moves))
    }
}

func TestCheckmateScholar(t *testing.T) {
    g := NewGame()
    g.MakeMove(Move{From: Square{6,4}, To: Square{4,4}})           // 1. e4
    g.MakeMove(Move{From: Square{1,4}, To: Square{3,4}})           // 1...e5
    g.MakeMove(Move{From: Square{7,3}, To: Square{3,7}})           // 2. Qh5
    g.MakeMove(Move{From: Square{0,1}, To: Square{2,2}})           // 2...Nc6
    g.MakeMove(Move{From: Square{7,5}, To: Square{4,2}})           // 3. Bc4
    g.MakeMove(Move{From: Square{0,6}, To: Square{2,5}})           // 3...Nf6??
    ok := g.MakeMove(Move{From: Square{3,7}, To: Square{1,5}})     // 4. Qxf7#
    if !ok { t.Fatal("Qxf7 应该是合法的，你是不是漏了吃子？") }
    if !g.IsCheckmate() { t.Error("学者杀走完应该是将死！") }
}
```

推荐的 6 个测试用例（本项目全部通过）：
1. 初始局面棋子数量
2. 开局 20 步合法走法
3. 简单兵移动 e2-e4
4. 学者杀验证将死判定
5. 王移动后易位权清零
6. 吃过路兵（含目标格设置 & 被吃兵清除）

> 💡 写测试看起来「多写了几百行」，但实际上**能为你省下数倍的 GUI 调试时间**。

---

## 5. 第三步：写 Fyne GUI —— main.go

### 5.1 为什么要自定义 Widget？

Fyne 自带的 `widget.Button`、`canvas.Rectangle` 都不够用。我们每个棋盘格子需要：
- 底色（交替的米/棕）
- 覆盖一层「高亮色」（选中、可走、将军…）
- 中间显示棋子 Unicode 字符
- 响应点击

**最干净的做法**：写一个自定义 Widget，叫 `squareCell`。

### 5.2 Fyne 自定义 Widget 的模板

Fyne 里自定义一个可点击 Widget 需要写 2 个部分：**结构体 + Renderer**。照这个模板抄，把你需要的字段加进去：

```go
// 1) 结构体：继承 BaseWidget，再挂你的字段 + Tapped 方法
type squareCell struct {
    widget.BaseWidget
    row, col int
    onTap    func(int, int)
    bg       color.Color
    piece    string
    pColor   color.Color
    hlColor  color.Color
}

func newSquareCell(r, c int, onTap func(int, int)) *squareCell {
    s := &squareCell{row: r, col: c, onTap: onTap}
    s.ExtendBaseWidget(s)   // ⚠️ 这一行别漏！
    return s
}

func (s *squareCell) Tapped(*fyne.PointEvent) {
    if s.onTap != nil { s.onTap(s.row, s.col) }
}

// 2) Renderer：负责画这个 Widget
type squareCellRenderer struct {
    cell     *squareCell
    bgRect   *canvas.Rectangle
    hlRect   *canvas.Rectangle
    pieceLbl *canvas.Text
}

func (s *squareCell) CreateRenderer() fyne.WidgetRenderer {
    bg  := canvas.NewRectangle(color.White)
    hl  := canvas.NewRectangle(color.Transparent)
    txt := canvas.NewText("  ", color.Black)
    txt.TextSize  = 42
    txt.Alignment = fyne.TextAlignCenter
    return &squareCellRenderer{cell: s, bgRect: bg, hlRect: hl, pieceLbl: txt}
}

// Layout / MinSize / Refresh / Objects / Destroy 这几个方法照抄即可，
// 核心是 Refresh() 里把字段值赋到 canvas 对象上然后 .Refresh()
```

> 💡 新手常见 bug：忘了写 `s.ExtendBaseWidget(s)` —— 结果就是 Widget 完全不显示。

### 5.3 棋子用 Unicode，不用图片

用 Unicode 象棋字符**完全不需要任何图片资源**，exe 拷到任何 Windows 机器都能跑：

```go
func PieceSymbol(p Piece) string {
    if p.Type == NoType { return "" }
    symbols := map[Color]map[PieceType]string{
        White: {Pawn: "♙", Knight: "♘", Bishop: "♗", Rook: "♖", Queen: "♕", King: "♔"},
        Black: {Pawn: "♟", Knight: "♞", Bishop: "♝", Rook: "♜", Queen: "♛", King: "♚"},
    }
    return symbols[p.Color][p.Type]
}
```

白方用浅色（比如 #fcfcfc）、黑方深色（#1e1e1e），效果接近标准木质棋盘。

### 5.4 高亮系统

我们准备 5 种半透明覆盖色：

| 颜色 | 含义 |
|------|------|
| 🟡 黄 | 当前选中的棋子 |
| 🟢 绿 | 该格是合法落子（空） |
| 🔴 红 | 该格能吃掉对方棋子 |
| 🟠 深黄 | 上一步的 From 和 To |
| 🔴 深红 | 王被将军 |

每次走子或选中后调用 `refreshAllHighlights()`，流程是：
1. 先把 64 格的高亮全部 `SetHighlight(nil)` 清掉
2. 再按需设置各种颜色

这种「先全清再重画」的写法虽然不最优，但**极其不闹鬼**，新手首选。

### 5.5 点击交互的状态机

点击某格后的判断逻辑用一个简单「状态机」：

```
当前没有选中的棋子:
    点到己方棋子 → 选中它，算好它的合法走子，画高亮
    点到空格/对方 → 什么都不做

当前有选中的棋子:
    点到自己 → 取消选中
    点到另一个己方棋子 → 切换选中对象
    点到合法走子的目标格 → 执行走子
    点到其他位置 → 取消选中
```

对应代码就是 `handleSquareClick(sq)` 的 if/else，写的时候照着上面的 4 条分支就不会乱。

### 5.6 兵升变对话框

如果走到底线的兵有多个合法升变选择（Q/R/B/N 都合法），就弹出一个 `dialog.ShowCustomConfirm` 让用户选，选完再调用 `MakeMove`。这里用 Fyne 自带的 `dialog` 就够了。

### 5.7 组装整个窗口

`main()` 很简单：

```go
func main() {
    a := app.New()
    a.Settings().SetTheme(theme.LightTheme())   // 浅色主题
    w := a.NewWindow("国际象棋 Chess")
    w.Resize(fyne.NewSize(960, 760))

    ca := NewChessApp()   // 应用对象（持有 engine、选中状态、8x8 cell 指针）
    ca.window = w

    ca.buildBoard()       // 初始化 64 个 cell 并塞进 board 容器
    sidePanel      := ca.buildSidePanel()            // 右侧状态栏
    boardWithLabels := ca.wrapBoardWithLabels(nil)   // 给棋盘加 a-h/1-8 标号

    // 用 Border 布局：棋盘放中间（左），侧栏贴右边
    content := container.NewBorder(nil, nil,
        container.NewPadded(boardWithLabels),
        container.NewPadded(sidePanel),
    )

    w.SetContent(content)
    ca.refreshPieces()
    ca.refreshAllHighlights()
    ca.updateStatus()
    w.ShowAndRun()
}
```

---

## 6. 第四步：编译 & 运行

### 6.1 直接出 exe

```powershell
cd C:\Users\你\Desktop\chess
go build -o chess.exe .
```

等大约 30 秒（首次编译 Fyne 比较慢，后面增量编译只要几秒），你会得到一个 ~48MB 的 `chess.exe`。

**双击就能跑**，不需要任何额外运行时。

### 6.2 跑单元测试

```powershell
go test ./engine/ -v
```

6 个测试全 PASS 就说明规则引擎没有大问题。

### 6.3 发布给朋友

直接把 `chess.exe` 打包成 zip 发出去就行，**不用带任何其他文件**（Fyne 静态编译，所有字体和 GUI 代码都在 exe 里）。

---

## 7. 常见问题 & 排错清单

### ❌ 编译报 `OnTapped undefined (type *fyne.Container has no field or method OnTapped)`
`container.NewStack()` / `container.NewGridWithColumns()` 返回的 `*fyne.Container` **不能直接挂 `.OnTapped`**。想让区域可点击，**请自定义 Widget 并实现 `Tappable` 接口**（即写 `Tapped` 方法 + `ExtendBaseWidget`）。这就是为什么我们写了 `squareCell`。

### ❌ 编译报 `invalid operation: p.Color == c (mismatched types Color and int)`
这是 Go 的强类型检查：你在 `for c := 0; c < 8; c++` 里声明了循环变量 `c`，结果下面的 `p.Color == c` 被解析成和循环变量 `int` 比了。**把循环变量改名叫 `col`，或把 `findKing(c Color)` 的参数名改成 `col`**。

### ❌ 开局算出来只有 4 步合法走子
**兵的起始行写错了**。白兵从 row=6 出发、黑兵从 row=1 出发（如果行 7 是白方底线），不是 row=7 和 row=0。看 `pawnMoves` 的 `startRow`。

### ❌ 合法走子过滤后，马能「送掉己方王」
说明 `GenerateLegalMoves` 里没有走「克隆 → 应用 → 查将军 → 不合法就丢弃」这条链路。回到 3.3 节照抄那个结构。

### ❌ 双击 exe 弹出黑框一闪而过
先在 PowerShell 里 `.\chess.exe` 跑，看报错信息。如果是缺少 OpenGL 驱动（极少见 Windows 新机器），更新显卡驱动即可。

### ❌ 棋子显示成方块「□」
系统缺 Unicode 象棋符号字体。Windows 10/11 自带的 Segoe UI Symbol、MS Gothic、SimSun 都支持；实在不行可以去 `fyne.io` 文档看 `fyneSettings` 如何指定自定义 TTF 字体并嵌入资源。

### ❌ 想加 AI 对弈、悔棋、存档
在现有代码基础上拓展非常自然：
- **悔棋**：给 `engine` 加一个 `UndoLastMove()`，把 `History` 里最后一条 `Move` 逆向应用（所以要把 `makeMove` 改写成可逆，或每次都存局面快照）
- **存档**：把局面转成 FEN 字符串存进文本文件；载入时解析 FEN
- **AI**：最经典的是 Minimax + Alpha-Beta 剪枝，深度 3–4 就已经能赢大部分新手了

---

## 8. 推荐阅读（巩固基础）

- Fyne 官方入门：<https://docs.fyne.io/started/>
- Fyne 自定义 Widget：<https://docs.fyne.io/extend/custom-widget>
- 国际象棋规则完整介绍（英文维基）：<https://en.wikipedia.org/wiki/Rules_of_chess>
- 「写一个象棋引擎」系列，进阶必看：<https://www.chessprogramming.org/Main_Page>

---

## 9. 项目文件导航（对照本仓库）

| 文件 | 行数 | 负责什么 |
|------|------|----------|
| [engine/chess.go](file:///c:/Users/Administrator/Desktop/agent_project/chess/engine/chess.go) | ~590 | 规则引擎全部 |
| [engine/chess_test.go](file:///c:/Users/Administrator/Desktop/agent_project/chess/engine/chess_test.go) | ~110 | 6 个单元测试 |
| [main.go](file:///c:/Users/Administrator/Desktop/agent_project/chess/main.go) | ~460 | Fyne GUI：自定义 cell / 应用 / 侧栏 / 对话框 |
| [go.mod](file:///c:/Users/Administrator/Desktop/agent_project/chess/go.mod) | | Go 模块定义 + Fyne 依赖 |

祝你写得开心 🎉
