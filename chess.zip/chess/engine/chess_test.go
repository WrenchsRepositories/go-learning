package engine

import "testing"

func TestInitialBoard(t *testing.T) {
	g := NewGame()
	// Each side: 8 pawns + 2 rooks + 2 knights + 2 bishops + 1 queen + 1 king = 16
	count := map[Color]int{White: 0, Black: 0}
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			p := g.Board[r][c]
			if p.Type != NoType {
				count[p.Color]++
			}
		}
	}
	if count[White] != 16 {
		t.Errorf("expected 16 white pieces, got %d", count[White])
	}
	if count[Black] != 16 {
		t.Errorf("expected 16 black pieces, got %d", count[Black])
	}
	if g.Turn != White {
		t.Errorf("expected white to move first")
	}
}

func TestLegalMovesCount(t *testing.T) {
	g := NewGame()
	moves := g.GenerateAllLegalMoves()
	// Standard chess opening: 20 legal moves for white (16 pawn, 4 knight)
	if len(moves) != 20 {
		t.Errorf("expected 20 opening moves, got %d", len(moves))
	}
}

func TestPawnMove(t *testing.T) {
	g := NewGame()
	// e2-e4
	mv := Move{From: Square{6, 4}, To: Square{4, 4}}
	if !g.MakeMove(mv) {
		t.Fatal("failed to make e2-e4")
	}
	if g.Board[4][4].Type != Pawn || g.Board[4][4].Color != White {
		t.Error("pawn not at e4")
	}
	if g.Turn != Black {
		t.Error("should be black's turn")
	}
}

func TestCheckmateScholar(t *testing.T) {
	g := NewGame()
	// Fool's mate? No - let's do scholar's mate simplified
	// 1. e4
	g.MakeMove(Move{From: Square{6, 4}, To: Square{4, 4}})
	// 1... e5
	g.MakeMove(Move{From: Square{1, 4}, To: Square{3, 4}})
	// 2. Qh5
	g.MakeMove(Move{From: Square{7, 3}, To: Square{3, 7}})
	// 2... Nc6
	g.MakeMove(Move{From: Square{0, 1}, To: Square{2, 2}})
	// 3. Bc4
	g.MakeMove(Move{From: Square{7, 5}, To: Square{4, 2}})
	// 3... Nf6??
	g.MakeMove(Move{From: Square{0, 6}, To: Square{2, 5}})
	// 4. Qxf7#
	ok := g.MakeMove(Move{From: Square{3, 7}, To: Square{1, 5}, Captured: Pawn})
	if !ok {
		// Qxf7 - check legality
		t.Fatal("Qxf7 should be legal")
	}
	if !g.IsCheckmate() {
		t.Error("expected checkmate after Qxf7# (scholar's mate)")
	}
}

func TestCastlingRightsLost(t *testing.T) {
	g := NewGame()
	// Use unexported makeMove directly (same package) to apply a king move without needing
	// to clear the board path, since MakeMove validates legality (and Ke1-f1 is blocked by Bf1).
	// The test verifies only that castling rights update logic fires when a king moves.
	g.makeMove(Move{From: Square{7, 4}, To: Square{7, 5}}) // Ke1-f1 via direct internal call
	if g.CastlingRights[0] || g.CastlingRights[1] {
		t.Error("white castling rights should be lost after king moved")
	}
}

func TestEnPassant(t *testing.T) {
	g := NewGame()
	// Setup en passant: white pawn on e5, black pawn d7-d5
	g.MakeMove(Move{From: Square{6, 4}, To: Square{4, 4}}) // e4
	g.MakeMove(Move{From: Square{1, 0}, To: Square{2, 0}}) // a6 (any)
	g.MakeMove(Move{From: Square{4, 4}, To: Square{3, 4}}) // e5
	g.MakeMove(Move{From: Square{1, 3}, To: Square{3, 3}}) // d7-d5 (two squares)
	if g.EnPassant == nil || g.EnPassant.Row != 2 || g.EnPassant.Col != 3 {
		t.Fatal("en passant target square not set correctly")
	}
	// White takes en passant: e5xd6
	ok := g.MakeMove(Move{From: Square{3, 4}, To: Square{2, 3}, IsEnPassant: true, Captured: Pawn})
	if !ok {
		t.Error("en passant capture should be legal")
	}
	// Black pawn on d5 should be gone
	if g.Board[3][3].Type != NoType {
		t.Error("captured pawn should be removed")
	}
}
