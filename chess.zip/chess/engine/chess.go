package engine

import (
	"fmt"
	"strings"
)

type Color int8

const (
	White Color = 1
	Black Color = -1
)

type PieceType int8

const (
	NoType PieceType = iota
	Pawn
	Knight
	Bishop
	Rook
	Queen
	King
)

type Piece struct {
	Type  PieceType
	Color Color
}

var NoPiece = Piece{}

type Square struct {
	Row, Col int
}

type Move struct {
	From       Square
	To         Square
	Captured   PieceType
	PromotedTo PieceType
	IsCastle   bool
	IsEnPassant bool
}

type GameState struct {
	Board          [8][8]Piece
	Turn           Color
	CastlingRights [4]bool // WK, WQ, BK, BQ
	EnPassant      *Square
	HalfMoveClock  int
	FullMoveNumber int
	History        []Move
}

func NewGame() *GameState {
	g := &GameState{
		Turn:           White,
		CastlingRights: [4]bool{true, true, true, true},
		FullMoveNumber: 1,
	}
	g.setupInitialPosition()
	return g
}

func (g *GameState) setupInitialPosition() {
	backRank := []PieceType{Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook}
	for col := 0; col < 8; col++ {
		g.Board[0][col] = Piece{Type: backRank[col], Color: Black}
		g.Board[1][col] = Piece{Type: Pawn, Color: Black}
		g.Board[6][col] = Piece{Type: Pawn, Color: White}
		g.Board[7][col] = Piece{Type: backRank[col], Color: White}
	}
}

func (s Square) IsValid() bool {
	return s.Row >= 0 && s.Row < 8 && s.Col >= 0 && s.Col < 8
}

func (s Square) String() string {
	return fmt.Sprintf("%c%d", 'a'+s.Col, 8-s.Row)
}

func (g *GameState) PieceAt(s Square) Piece {
	if !s.IsValid() {
		return NoPiece
	}
	return g.Board[s.Row][s.Col]
}

func (g *GameState) SetPiece(s Square, p Piece) {
	if s.IsValid() {
		g.Board[s.Row][s.Col] = p
	}
}

func (g *GameState) clone() *GameState {
	ng := &GameState{
		Turn:           g.Turn,
		CastlingRights: g.CastlingRights,
		HalfMoveClock:  g.HalfMoveClock,
		FullMoveNumber: g.FullMoveNumber,
		History:        make([]Move, len(g.History)),
	}
	copy(ng.History, g.History)
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			ng.Board[r][c] = g.Board[r][c]
		}
	}
	if g.EnPassant != nil {
		ep := *g.EnPassant
		ng.EnPassant = &ep
	}
	return ng
}

func (g *GameState) GenerateLegalMoves(from Square) []Move {
	p := g.PieceAt(from)
	if p.Type == NoType || p.Color != g.Turn {
		return nil
	}

	pseudo := g.generatePseudoMoves(from, p)
	legal := make([]Move, 0, len(pseudo))
	for _, m := range pseudo {
		ng := g.clone()
		ng.makeMove(m)
		if !ng.isKingInCheck(p.Color) {
			legal = append(legal, m)
		}
	}
	return legal
}

func (g *GameState) GenerateAllLegalMoves() []Move {
	var moves []Move
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			sq := Square{r, c}
			p := g.PieceAt(sq)
			if p.Color == g.Turn && p.Type != NoType {
				moves = append(moves, g.GenerateLegalMoves(sq)...)
			}
		}
	}
	return moves
}

func (g *GameState) generatePseudoMoves(from Square, p Piece) []Move {
	switch p.Type {
	case Pawn:
		return g.pawnMoves(from, p)
	case Knight:
		return g.knightMoves(from, p)
	case Bishop:
		return g.slidingMoves(from, p, [][2]int{{-1, -1}, {-1, 1}, {1, -1}, {1, 1}})
	case Rook:
		return g.slidingMoves(from, p, [][2]int{{-1, 0}, {1, 0}, {0, -1}, {0, 1}})
	case Queen:
		return g.slidingMoves(from, p, [][2]int{{-1, -1}, {-1, 1}, {1, -1}, {1, 1}, {-1, 0}, {1, 0}, {0, -1}, {0, 1}})
	case King:
		return g.kingMoves(from, p)
	}
	return nil
}

func (g *GameState) pawnMoves(from Square, p Piece) []Move {
	var moves []Move
	var dir, startRow, promoteRow int
	if p.Color == White {
		dir = -1        // move up (row decreases)
		startRow = 6    // white pawns start on row 6
		promoteRow = 0
	} else {
		dir = 1         // move down (row increases)
		startRow = 1    // black pawns start on row 1
		promoteRow = 7
	}

	// Forward 1
	s1 := Square{from.Row + dir, from.Col}
	if s1.IsValid() && g.PieceAt(s1).Type == NoType {
		if s1.Row == promoteRow {
			for _, pt := range []PieceType{Queen, Rook, Bishop, Knight} {
				moves = append(moves, Move{From: from, To: s1, PromotedTo: pt})
			}
		} else {
			moves = append(moves, Move{From: from, To: s1})
		}

		// Forward 2 from start
		s2 := Square{from.Row + 2*dir, from.Col}
		if from.Row == startRow && g.PieceAt(s2).Type == NoType {
			moves = append(moves, Move{From: from, To: s2})
		}
	}

	// Captures
	for _, dc := range []int{-1, 1} {
		cs := Square{from.Row + dir, from.Col + dc}
		if cs.IsValid() {
			target := g.PieceAt(cs)
			if target.Type != NoType && target.Color != p.Color {
				if cs.Row == promoteRow {
					for _, pt := range []PieceType{Queen, Rook, Bishop, Knight} {
						moves = append(moves, Move{From: from, To: cs, Captured: target.Type, PromotedTo: pt})
					}
				} else {
					moves = append(moves, Move{From: from, To: cs, Captured: target.Type})
				}
			}
			// En passant
			if g.EnPassant != nil && cs.Row == g.EnPassant.Row && cs.Col == g.EnPassant.Col {
				moves = append(moves, Move{From: from, To: cs, IsEnPassant: true, Captured: Pawn})
			}
		}
	}
	return moves
}

func (g *GameState) knightMoves(from Square, p Piece) []Move {
	var moves []Move
	offsets := [][2]int{{-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}}
	for _, o := range offsets {
		to := Square{from.Row + o[0], from.Col + o[1]}
		if !to.IsValid() {
			continue
		}
		target := g.PieceAt(to)
		if target.Type == NoType {
			moves = append(moves, Move{From: from, To: to})
		} else if target.Color != p.Color {
			moves = append(moves, Move{From: from, To: to, Captured: target.Type})
		}
	}
	return moves
}

func (g *GameState) slidingMoves(from Square, p Piece, dirs [][2]int) []Move {
	var moves []Move
	for _, d := range dirs {
		for i := 1; i < 8; i++ {
			to := Square{from.Row + d[0]*i, from.Col + d[1]*i}
			if !to.IsValid() {
				break
			}
			target := g.PieceAt(to)
			if target.Type == NoType {
				moves = append(moves, Move{From: from, To: to})
			} else {
				if target.Color != p.Color {
					moves = append(moves, Move{From: from, To: to, Captured: target.Type})
				}
				break
			}
		}
	}
	return moves
}

func (g *GameState) kingMoves(from Square, p Piece) []Move {
	var moves []Move
	// Normal king moves
	for dr := -1; dr <= 1; dr++ {
		for dc := -1; dc <= 1; dc++ {
			if dr == 0 && dc == 0 {
				continue
			}
			to := Square{from.Row + dr, from.Col + dc}
			if !to.IsValid() {
				continue
			}
			target := g.PieceAt(to)
			if target.Type == NoType {
				moves = append(moves, Move{From: from, To: to})
			} else if target.Color != p.Color {
				moves = append(moves, Move{From: from, To: to, Captured: target.Type})
			}
		}
	}
	// Castling
	if !g.isKingInCheck(p.Color) {
		if p.Color == White {
			// Kingside
			if g.CastlingRights[0] && g.PieceAt(Square{7, 5}).Type == NoType && g.PieceAt(Square{7, 6}).Type == NoType &&
				g.PieceAt(Square{7, 7}).Type == Rook && g.PieceAt(Square{7, 7}).Color == White {
				if !g.isSquareAttacked(Square{7, 5}, Black) && !g.isSquareAttacked(Square{7, 6}, Black) {
					moves = append(moves, Move{From: from, To: Square{7, 6}, IsCastle: true})
				}
			}
			// Queenside
			if g.CastlingRights[1] && g.PieceAt(Square{7, 1}).Type == NoType && g.PieceAt(Square{7, 2}).Type == NoType &&
				g.PieceAt(Square{7, 3}).Type == NoType && g.PieceAt(Square{7, 0}).Type == Rook && g.PieceAt(Square{7, 0}).Color == White {
				if !g.isSquareAttacked(Square{7, 2}, Black) && !g.isSquareAttacked(Square{7, 3}, Black) {
					moves = append(moves, Move{From: from, To: Square{7, 2}, IsCastle: true})
				}
			}
		} else {
			// Kingside
			if g.CastlingRights[2] && g.PieceAt(Square{0, 5}).Type == NoType && g.PieceAt(Square{0, 6}).Type == NoType &&
				g.PieceAt(Square{0, 7}).Type == Rook && g.PieceAt(Square{0, 7}).Color == Black {
				if !g.isSquareAttacked(Square{0, 5}, White) && !g.isSquareAttacked(Square{0, 6}, White) {
					moves = append(moves, Move{From: from, To: Square{0, 6}, IsCastle: true})
				}
			}
			// Queenside
			if g.CastlingRights[3] && g.PieceAt(Square{0, 1}).Type == NoType && g.PieceAt(Square{0, 2}).Type == NoType &&
				g.PieceAt(Square{0, 3}).Type == NoType && g.PieceAt(Square{0, 0}).Type == Rook && g.PieceAt(Square{0, 0}).Color == Black {
				if !g.isSquareAttacked(Square{0, 2}, White) && !g.isSquareAttacked(Square{0, 3}, White) {
					moves = append(moves, Move{From: from, To: Square{0, 2}, IsCastle: true})
				}
			}
		}
	}
	return moves
}

func (g *GameState) isSquareAttacked(sq Square, by Color) bool {
	// Pawn attacks
	// White pawn at (r, c) attacks (r-1, c-1) and (r-1, c+1)
	// So if attacker=White, attacking pawn is at sq.Row+1
	// Black pawn at (r, c) attacks (r+1, c-1) and (r+1, c+1)
	// So if attacker=Black, attacking pawn is at sq.Row-1
	pawnSrcRow := sq.Row + 1
	if by == Black {
		pawnSrcRow = sq.Row - 1
	}
	for _, dc := range []int{-1, 1} {
		ps := Square{pawnSrcRow, sq.Col - dc}
		if ps.IsValid() {
			p := g.PieceAt(ps)
			if p.Type == Pawn && p.Color == by {
				return true
			}
		}
	}
	// Knight
	koffsets := [][2]int{{-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}}
	for _, o := range koffsets {
		ts := Square{sq.Row + o[0], sq.Col + o[1]}
		if ts.IsValid() {
			p := g.PieceAt(ts)
			if p.Type == Knight && p.Color == by {
				return true
			}
		}
	}
	// King
	for dr := -1; dr <= 1; dr++ {
		for dc := -1; dc <= 1; dc++ {
			if dr == 0 && dc == 0 {
				continue
			}
			ts := Square{sq.Row + dr, sq.Col + dc}
			if ts.IsValid() {
				p := g.PieceAt(ts)
				if p.Type == King && p.Color == by {
					return true
				}
			}
		}
	}
	// Sliding: bishops/queens diagonals
	bdirs := [][2]int{{-1, -1}, {-1, 1}, {1, -1}, {1, 1}}
	for _, d := range bdirs {
		for i := 1; i < 8; i++ {
			ts := Square{sq.Row + d[0]*i, sq.Col + d[1]*i}
			if !ts.IsValid() {
				break
			}
			p := g.PieceAt(ts)
			if p.Type != NoType {
				if p.Color == by && (p.Type == Bishop || p.Type == Queen) {
					return true
				}
				break
			}
		}
	}
	// Sliding: rooks/queens straights
	rdirs := [][2]int{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}
	for _, d := range rdirs {
		for i := 1; i < 8; i++ {
			ts := Square{sq.Row + d[0]*i, sq.Col + d[1]*i}
			if !ts.IsValid() {
				break
			}
			p := g.PieceAt(ts)
			if p.Type != NoType {
				if p.Color == by && (p.Type == Rook || p.Type == Queen) {
					return true
				}
				break
			}
		}
	}
	return false
}

func (g *GameState) findKing(col Color) Square {
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			p := g.Board[r][c]
			if p.Type == King && p.Color == col {
				return Square{r, c}
			}
		}
	}
	return Square{-1, -1}
}

func (g *GameState) isKingInCheck(c Color) bool {
	k := g.findKing(c)
	if k.Row < 0 {
		return false
	}
	opp := White
	if c == White {
		opp = Black
	}
	return g.isSquareAttacked(k, opp)
}

func (g *GameState) IsCheck() bool {
	return g.isKingInCheck(g.Turn)
}

func (g *GameState) makeMove(m Move) {
	p := g.PieceAt(m.From)
	g.SetPiece(m.To, p)
	g.SetPiece(m.From, NoPiece)

	if m.IsEnPassant {
		captRow := m.To.Row + 1 // White captures: pawn was at to.Row+1
		if p.Color == Black {
			captRow = m.To.Row - 1 // Black captures: pawn was at to.Row-1
		}
		g.SetPiece(Square{captRow, m.To.Col}, NoPiece)
	}
	if m.IsCastle {
		if m.To.Col == 6 { // Kingside
			g.SetPiece(Square{m.To.Row, 5}, g.PieceAt(Square{m.To.Row, 7}))
			g.SetPiece(Square{m.To.Row, 7}, NoPiece)
		} else { // Queenside
			g.SetPiece(Square{m.To.Row, 3}, g.PieceAt(Square{m.To.Row, 0}))
			g.SetPiece(Square{m.To.Row, 0}, NoPiece)
		}
	}
	if m.PromotedTo != NoType {
		g.SetPiece(m.To, Piece{Type: m.PromotedTo, Color: p.Color})
	}

	// Update castling rights
	if p.Type == King {
		if p.Color == White {
			g.CastlingRights[0] = false
			g.CastlingRights[1] = false
		} else {
			g.CastlingRights[2] = false
			g.CastlingRights[3] = false
		}
	}
	if p.Type == Rook {
		if m.From.Row == 7 && m.From.Col == 0 {
			g.CastlingRights[1] = false
		}
		if m.From.Row == 7 && m.From.Col == 7 {
			g.CastlingRights[0] = false
		}
		if m.From.Row == 0 && m.From.Col == 0 {
			g.CastlingRights[3] = false
		}
		if m.From.Row == 0 && m.From.Col == 7 {
			g.CastlingRights[2] = false
		}
	}
	if m.Captured == Rook {
		if m.To.Row == 7 && m.To.Col == 0 {
			g.CastlingRights[1] = false
		}
		if m.To.Row == 7 && m.To.Col == 7 {
			g.CastlingRights[0] = false
		}
		if m.To.Row == 0 && m.To.Col == 0 {
			g.CastlingRights[3] = false
		}
		if m.To.Row == 0 && m.To.Col == 7 {
			g.CastlingRights[2] = false
		}
	}

	// En passant target
	g.EnPassant = nil
	if p.Type == Pawn && (m.To.Row-m.From.Row == 2 || m.To.Row-m.From.Row == -2) {
		epRow := (m.To.Row + m.From.Row) / 2
		g.EnPassant = &Square{epRow, m.From.Col}
	}

	// Half-move clock
	if p.Type == Pawn || m.Captured != NoType {
		g.HalfMoveClock = 0
	} else {
		g.HalfMoveClock++
	}

	if g.Turn == Black {
		g.FullMoveNumber++
	}
	g.Turn = -g.Turn
}

func (g *GameState) MakeMove(m Move) bool {
	legal := g.GenerateLegalMoves(m.From)
	for _, lm := range legal {
		if lm.From == m.From && lm.To == m.To && lm.PromotedTo == m.PromotedTo {
			g.makeMove(m)
			g.History = append(g.History, m)
			return true
		}
	}
	return false
}

func (g *GameState) IsCheckmate() bool {
	return g.IsCheck() && len(g.GenerateAllLegalMoves()) == 0
}

func (g *GameState) IsStalemate() bool {
	return !g.IsCheck() && len(g.GenerateAllLegalMoves()) == 0
}

func (g *GameState) IsDraw() bool {
	return g.IsStalemate() || g.HalfMoveClock >= 100
}

func (g *GameState) Status() string {
	switch {
	case g.IsCheckmate():
		winner := "黑方"
		if g.Turn == Black {
			winner = "白方"
		}
		return fmt.Sprintf("将死！%s获胜", winner)
	case g.IsStalemate():
		return "逼和！"
	case g.HalfMoveClock >= 100:
		return "和棋（50回合规则）"
	case g.IsCheck():
		side := "白方"
		if g.Turn == Black {
			side = "黑方"
		}
		return fmt.Sprintf("%s被将军", side)
	default:
		side := "白方"
		if g.Turn == Black {
			side = "黑方"
		}
		return fmt.Sprintf("%s走棋", side)
	}
}

func PieceSymbol(p Piece) string {
	if p.Type == NoType {
		return ""
	}
	symbols := map[Color]map[PieceType]string{
		White: {Pawn: "♙", Knight: "♘", Bishop: "♗", Rook: "♖", Queen: "♕", King: "♔"},
		Black: {Pawn: "♟", Knight: "♞", Bishop: "♝", Rook: "♜", Queen: "♛", King: "♚"},
	}
	return symbols[p.Color][p.Type]
}

func PieceSymbolText(p Piece) string {
	if p.Type == NoType {
		return "."
	}
	symbols := map[Color]map[PieceType]string{
		White: {Pawn: "P", Knight: "N", Bishop: "B", Rook: "R", Queen: "Q", King: "K"},
		Black: {Pawn: "p", Knight: "n", Bishop: "b", Rook: "r", Queen: "q", King: "k"},
	}
	return symbols[p.Color][p.Type]
}

func (g *GameState) FindKing(c Color) Square {
	return g.findKing(c)
}

func (g *GameState) DebugBoard() string {
	var sb strings.Builder
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			sb.WriteString(PieceSymbolText(g.Board[r][c]))
			sb.WriteByte(' ')
		}
		sb.WriteByte('\n')
	}
	return sb.String()
}
