package main

import (
	"fmt"
	"image/color"

	"chess/engine"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/data/binding"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
)

var (
	lightSq  = color.RGBA{R: 240, G: 217, B: 181, A: 255}
	darkSq   = color.RGBA{R: 181, G: 136, B: 99, A: 255}
	selCol   = color.RGBA{R: 255, G: 253, B: 100, A: 180}
	moveCol  = color.RGBA{R: 60, G: 200, B: 60, A: 140}
	capCol   = color.RGBA{R: 230, G: 60, B: 60, A: 160}
	chCol    = color.RGBA{R: 255, G: 80, B: 80, A: 180}
	lmCol    = color.RGBA{R: 170, G: 160, B: 80, A: 140}
)

type squareCell struct {
	widget.BaseWidget
	row, col int
	onTap    func(int, int)

	bg      color.Color
	piece   string
	pColor  color.Color
	hlColor color.Color
}

func newSquareCell(r, c int, onTap func(int, int)) *squareCell {
	s := &squareCell{row: r, col: c, onTap: onTap}
	s.ExtendBaseWidget(s)
	return s
}

func (s *squareCell) SetBackground(c color.Color) {
	s.bg = c
	s.Refresh()
}

func (s *squareCell) SetPiece(piece string, pc color.Color) {
	s.piece = piece
	s.pColor = pc
	s.Refresh()
}

func (s *squareCell) SetHighlight(c color.Color) {
	s.hlColor = c
	s.Refresh()
}

func (s *squareCell) Tapped(*fyne.PointEvent) {
	if s.onTap != nil {
		s.onTap(s.row, s.col)
	}
}

type squareCellRenderer struct {
	cell     *squareCell
	bgRect   *canvas.Rectangle
	hlRect   *canvas.Rectangle
	pieceLbl *canvas.Text
}

func (s *squareCell) CreateRenderer() fyne.WidgetRenderer {
	bg := canvas.NewRectangle(color.White)
	hl := canvas.NewRectangle(color.Transparent)
	txt := canvas.NewText("  ", color.Black)
	txt.TextSize = 42
	txt.Alignment = fyne.TextAlignCenter
	r := &squareCellRenderer{cell: s, bgRect: bg, hlRect: hl, pieceLbl: txt}
	return r
}

func (r *squareCellRenderer) Layout(size fyne.Size) {
	r.bgRect.Resize(size)
	r.bgRect.Move(fyne.NewPos(0, 0))
	r.hlRect.Resize(size)
	r.hlRect.Move(fyne.NewPos(0, 0))
	r.pieceLbl.Resize(size)
	r.pieceLbl.Move(fyne.NewPos(0, 0))
}

func (r *squareCellRenderer) MinSize() fyne.Size {
	return fyne.NewSize(64, 64)
}

func (r *squareCellRenderer) Refresh() {
	if r.cell.bg != nil {
		r.bgRect.FillColor = r.cell.bg
	}
	r.bgRect.Refresh()
	if r.cell.hlColor != nil {
		r.hlRect.FillColor = r.cell.hlColor
	} else {
		r.hlRect.FillColor = color.Transparent
	}
	r.hlRect.Refresh()
	r.pieceLbl.Text = r.cell.piece
	if r.cell.pColor != nil {
		r.pieceLbl.Color = r.cell.pColor
	}
	r.pieceLbl.Refresh()
}

func (r *squareCellRenderer) BackgroundColor() color.Color {
	return color.Transparent
}

func (r *squareCellRenderer) Objects() []fyne.CanvasObject {
	return []fyne.CanvasObject{r.bgRect, r.hlRect, r.pieceLbl}
}

func (r *squareCellRenderer) Destroy() {}

type ChessApp struct {
	game        *engine.GameState
	selected    *engine.Square
	legalMoves  []engine.Move
	squares     [8][8]*squareCell
	statusLabel *widget.Label
	lastMove    *engine.Move
	statusBound binding.String
	turnBound   binding.String
	window      fyne.Window
}

func NewChessApp() *ChessApp {
	return &ChessApp{
		game:        engine.NewGame(),
		statusBound: binding.NewString(),
		turnBound:   binding.NewString(),
	}
}

func (ca *ChessApp) updateStatus() {
	ca.statusBound.Set(ca.game.Status())
	turn := "白方 (White)"
	if ca.game.Turn == engine.Black {
		turn = "黑方 (Black)"
	}
	ca.turnBound.Set(turn)
}

func (ca *ChessApp) buildBoard() *fyne.Container {
	board := container.NewGridWithColumns(8)
	onCellTap := func(r, c int) {
		ca.handleSquareClick(engine.Square{Row: r, Col: c})
	}
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			bg := lightSq
			if (r+c)%2 == 1 {
				bg = darkSq
			}
			cell := newSquareCell(r, c, onCellTap)
			cell.SetBackground(bg)
			ca.squares[r][c] = cell
			board.Add(cell)
		}
	}
	return board
}

func (ca *ChessApp) refreshAllHighlights() {
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			ca.squares[r][c].SetHighlight(nil)
		}
	}
	if ca.lastMove != nil {
		ca.squares[ca.lastMove.From.Row][ca.lastMove.From.Col].SetHighlight(lmCol)
		ca.squares[ca.lastMove.To.Row][ca.lastMove.To.Col].SetHighlight(lmCol)
	}
	if ca.selected != nil {
		ca.squares[ca.selected.Row][ca.selected.Col].SetHighlight(selCol)
		for _, m := range ca.legalMoves {
			if m.Captured != engine.NoType || m.IsEnPassant {
				ca.squares[m.To.Row][m.To.Col].SetHighlight(capCol)
			} else {
				ca.squares[m.To.Row][m.To.Col].SetHighlight(moveCol)
			}
		}
	}
	if ca.game.IsCheck() {
		k := ca.game.FindKing(ca.game.Turn)
		if k.Row >= 0 {
			ca.squares[k.Row][k.Col].SetHighlight(chCol)
		}
	}
}

func (ca *ChessApp) refreshPieces() {
	for r := 0; r < 8; r++ {
		for c := 0; c < 8; c++ {
			p := ca.game.Board[r][c]
			pc := color.Color(color.RGBA{R: 30, G: 30, B: 30, A: 255})
			if p.Color == engine.White {
				pc = color.RGBA{R: 252, G: 252, B: 252, A: 255}
			}
			if p.Type == engine.NoType {
				pc = color.Transparent
			}
			ca.squares[r][c].SetPiece(engine.PieceSymbol(p), pc)
		}
	}
}

func (ca *ChessApp) findLegalMove(to engine.Square) *engine.Move {
	for i := range ca.legalMoves {
		m := ca.legalMoves[i]
		if m.To == to {
			return &m
		}
	}
	return nil
}

func (ca *ChessApp) showPromotionDialog(onSelect func(engine.PieceType)) {
	opts := []engine.PieceType{engine.Queen, engine.Rook, engine.Bishop, engine.Knight}
	names := map[engine.PieceType]string{
		engine.Queen:  "♛ 后 Queen",
		engine.Rook:   "♜ 车 Rook",
		engine.Bishop: "♝ 象 Bishop",
		engine.Knight: "♞ 马 Knight",
	}
	if ca.game.Turn == engine.White {
		names[engine.Queen] = "♕ 后 Queen"
		names[engine.Rook] = "♖ 车 Rook"
		names[engine.Bishop] = "♗ 象 Bishop"
		names[engine.Knight] = "♘ 马 Knight"
	}
	buttons := container.NewGridWithColumns(4)
	var chosen engine.PieceType
	hasChosen := false
	for _, pt := range opts {
		p := pt
		btn := widget.NewButton(names[p], func() {
			chosen = p
			hasChosen = true
		})
		buttons.Add(btn)
	}
	content := container.NewVBox(
		widget.NewLabel("选择升变棋子 / Choose promotion piece:"),
		buttons,
	)
	dialog.ShowCustomConfirm("兵升变 Pawn Promotion", "确认 OK", "取消 Cancel", content, func(confirmed bool) {
		if confirmed && hasChosen {
			onSelect(chosen)
		}
	}, ca.window)
}

func (ca *ChessApp) handleSquareClick(sq engine.Square) {
	if ca.game.IsCheckmate() || ca.game.IsStalemate() {
		return
	}
	p := ca.game.PieceAt(sq)

	if ca.selected != nil {
		if *ca.selected == sq {
			ca.selected = nil
			ca.legalMoves = nil
			ca.refreshAllHighlights()
			return
		}
		if p.Color == ca.game.Turn && p.Type != engine.NoType {
			ca.selected = &sq
			ca.legalMoves = ca.game.GenerateLegalMoves(sq)
			ca.refreshAllHighlights()
			return
		}
		mv := ca.findLegalMove(sq)
		if mv == nil {
			ca.selected = nil
			ca.legalMoves = nil
			ca.refreshAllHighlights()
			return
		}

		fromPiece := ca.game.PieceAt(mv.From)
		_ = fromPiece
		needsPromotionDialog := false
		if mv.PromotedTo != engine.NoType {
			count := 0
			for _, lm := range ca.legalMoves {
				if lm.To == sq {
					count++
				}
			}
			if count > 1 {
				needsPromotionDialog = true
			}
		}

		execMove := func(pt engine.PieceType) {
			final := *mv
			final.PromotedTo = pt
			if ca.game.MakeMove(final) {
				ca.lastMove = &final
				ca.selected = nil
				ca.legalMoves = nil
				ca.refreshPieces()
				ca.refreshAllHighlights()
				ca.updateStatus()
			}
		}

		if needsPromotionDialog {
			ca.showPromotionDialog(func(pt engine.PieceType) {
				execMove(pt)
			})
		} else {
			execMove(mv.PromotedTo)
		}
		return
	}

	if p.Color == ca.game.Turn && p.Type != engine.NoType {
		ca.selected = &sq
		ca.legalMoves = ca.game.GenerateLegalMoves(sq)
		ca.refreshAllHighlights()
	}
}

func (ca *ChessApp) buildSidePanel() *fyne.Container {
	title := canvas.NewText("国际象棋 Chess", color.Black)
	title.TextSize = 22
	title.TextStyle = fyne.TextStyle{Bold: true}
	title.Alignment = fyne.TextAlignCenter

	turnLbl := widget.NewLabelWithData(ca.turnBound)
	turnLbl.Alignment = fyne.TextAlignCenter
	turnLbl.TextStyle = fyne.TextStyle{Bold: true}

	status := widget.NewLabelWithData(ca.statusBound)
	status.Alignment = fyne.TextAlignCenter
	status.Wrapping = fyne.TextWrapWord
	ca.statusLabel = status

	sep := widget.NewSeparator()

	newGameBtn := widget.NewButtonWithIcon("新游戏 New Game", theme.MediaReplayIcon(), func() {
		ca.game = engine.NewGame()
		ca.selected = nil
		ca.legalMoves = nil
		ca.lastMove = nil
		ca.refreshPieces()
		ca.refreshAllHighlights()
		ca.updateStatus()
	})

	helpText := widget.NewLabel(
		"操作说明 How to play:\n" +
			"• 点击己方棋子选中 / Click to select\n" +
			"• 绿色 = 可移动 / Green = move\n" +
			"• 红色 = 可吃子 / Red = capture\n" +
			"• 黄色 = 选中 / Yellow = selected\n" +
			"• 深黄 = 上一步 / Dark yellow = last move\n" +
			"• 红色高亮 = 被将军 / Red highlight = in check")
	helpText.Wrapping = fyne.TextWrapWord

	panel := container.NewVBox(
		container.NewCenter(title),
		widget.NewCard("当前回合 Turn", "", turnLbl),
		widget.NewCard("游戏状态 Status", "", status),
		sep,
		newGameBtn,
		sep,
		widget.NewCard("提示 Help", "", helpText),
	)
	return panel
}

func (ca *ChessApp) wrapBoardWithLabels(board *fyne.Container) *fyne.Container {
	files := []string{"a", "b", "c", "d", "e", "f", "g", "h"}
	ranks := []string{"8", "7", "6", "5", "4", "3", "2", "1"}

	mkLab := func(s string) *fyne.Container {
		l := widget.NewLabel(s)
		l.Alignment = fyne.TextAlignCenter
		return container.NewCenter(l)
	}

	top := container.NewGridWithColumns(10)
	top.Add(layout.NewSpacer())
	for _, f := range files {
		top.Add(mkLab(f))
	}
	top.Add(layout.NewSpacer())

	body := container.NewVBox()
	for r := 0; r < 8; r++ {
		rowGrid := container.NewGridWithColumns(10)
		rowGrid.Add(mkLab(ranks[r]))
		for c := 0; c < 8; c++ {
			rowGrid.Add(ca.squares[r][c])
		}
		rowGrid.Add(mkLab(ranks[r]))
		body.Add(rowGrid)
	}

	bottom := container.NewGridWithColumns(10)
	bottom.Add(layout.NewSpacer())
	for _, f := range files {
		bottom.Add(mkLab(f))
	}
	bottom.Add(layout.NewSpacer())

	return container.NewVBox(top, body, bottom)
}

func main() {
	a := app.New()
	a.Settings().SetTheme(theme.LightTheme())
	w := a.NewWindow("国际象棋 Chess")
	w.Resize(fyne.NewSize(960, 760))
	w.SetFixedSize(false)

	ca := NewChessApp()
	ca.window = w

	ca.buildBoard() // populates ca.squares

	sidePanel := ca.buildSidePanel()
	boardWithLabels := ca.wrapBoardWithLabels(nil)

	content := container.NewBorder(
		nil, nil,
		container.NewPadded(boardWithLabels),
		container.NewPadded(sidePanel),
	)

	w.SetContent(content)
	ca.refreshPieces()
	ca.refreshAllHighlights()
	ca.updateStatus()

	fmt.Println("国际象棋程序已启动 / Chess application started")
	w.ShowAndRun()
}
