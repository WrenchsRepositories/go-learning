package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"io/fs"
	"log"
	"net/http"
	"sync"
	"time"
)

//go:embed templates/*.html
var templateFS embed.FS

//go:embed static/*
var staticFS embed.FS

type Session struct {
	Username  string
	CreatedAt time.Time
}

var (
	sessions   = make(map[string]Session)
	sessionsMu sync.RWMutex
	templates  *template.Template
)

type User struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

var validUsers = map[string]string{
	"admin":    "password",
	"ctos":     "ctos123",
	"operator": "operator",
}

func main() {
	var err error
	templates, err = template.ParseFS(templateFS, "templates/*.html")
	if err != nil {
		log.Fatalf("Failed to parse templates: %v", err)
	}

	mux := http.NewServeMux()

	staticSub, err := fs.Sub(staticFS, "static")
	if err != nil {
		log.Fatalf("Failed to create static sub-fs: %v", err)
	}
	mux.Handle("GET /static/", http.StripPrefix("/static/", http.FileServer(http.FS(staticSub))))
	mux.HandleFunc("GET /", handleRoot)
	mux.HandleFunc("GET /login", handleLoginPage)
	mux.HandleFunc("POST /api/login", handleLogin)
	mux.HandleFunc("POST /api/logout", handleLogout)
	mux.HandleFunc("GET /dashboard", handleDashboard)
	mux.HandleFunc("GET /api/status", handleStatus)

	go cleanupSessions()

	addr := ":8787"
	fmt.Println("ctOS Central Operating System")
	fmt.Println("================================")
	fmt.Printf("Server starting on http://localhost%s\n", addr)
	fmt.Println("Default accounts:")
	fmt.Println("  - admin / password")
	fmt.Println("  - ctos / ctos123")
	fmt.Println("  - operator / operator")
	fmt.Println()

	if err := http.ListenAndServe(addr, loggingMiddleware(mux)); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}

func loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		log.Printf("[%s] %s %s %v", r.Method, r.URL.Path, r.RemoteAddr, time.Since(start))
	})
}

func handleRoot(w http.ResponseWriter, r *http.Request) {
	if session, ok := getSession(r); ok {
		data := map[string]interface{}{
			"Username": session.Username,
		}
		templates.ExecuteTemplate(w, "dashboard.html", data)
		return
	}
	http.Redirect(w, r, "/login", http.StatusFound)
}

func handleLoginPage(w http.ResponseWriter, r *http.Request) {
	templates.ExecuteTemplate(w, "login.html", nil)
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	var user User
	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		http.Error(w, `{"error":"Invalid request body"}`, http.StatusBadRequest)
		return
	}

	expectedPass, ok := validUsers[user.Username]
	if !ok || expectedPass != user.Password {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "AUTH_FAILED",
			"message": "Invalid credentials. Access denied.",
		})
		return
	}

	sessionID, err := generateSessionID()
	if err != nil {
		http.Error(w, `{"error":"Internal server error"}`, http.StatusInternalServerError)
		return
	}

	sessionsMu.Lock()
	sessions[sessionID] = Session{
		Username:  user.Username,
		CreatedAt: time.Now(),
	}
	sessionsMu.Unlock()

	http.SetCookie(w, &http.Cookie{
		Name:     "ctos_session",
		Value:    sessionID,
		Path:     "/",
		HttpOnly: true,
		Secure:   false,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   86400,
	})

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "Authentication successful",
		"user": map[string]string{
			"username": user.Username,
			"role":     getUserRole(user.Username),
			"id":       generateUserID(),
			"class":    getUserClass(user.Username),
		},
		"redirect": "/dashboard",
	})
}

func handleLogout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("ctos_session")
	if err == nil {
		sessionsMu.Lock()
		delete(sessions, cookie.Value)
		sessionsMu.Unlock()
	}

	http.SetCookie(w, &http.Cookie{
		Name:     "ctos_session",
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		MaxAge:   -1,
	})

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "Session terminated",
	})
}

func handleDashboard(w http.ResponseWriter, r *http.Request) {
	session, ok := getSession(r)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	data := map[string]interface{}{
		"Username":  session.Username,
		"Role":      getUserRole(session.Username),
		"ID":        generateUserID(),
		"Class":     getUserClass(session.Username),
		"LoginTime": session.CreatedAt.Format("2006-01-02 15:04:05"),
	}
	templates.ExecuteTemplate(w, "dashboard.html", data)
}

func handleStatus(w http.ResponseWriter, r *http.Request) {
	_, ok := getSession(r)
	if !ok {
		http.Error(w, `{"error":"Unauthorized"}`, http.StatusUnauthorized)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"timestamp": time.Now().Format(time.RFC3339),
		"uptime":    "14d 08h 32m",
		"node":      "ctos-primary-node-01",
		"status":    "OPERATIONAL",
		"services": []map[string]interface{}{
			{"name": "AUTH", "status": "ONLINE", "load": 23},
			{"name": "SURVEILLANCE", "status": "ONLINE", "load": 67},
			{"name": "TRAFFIC", "status": "ONLINE", "load": 41},
			{"name": "POWER_GRID", "status": "ONLINE", "load": 15},
			{"name": "WATER", "status": "ONLINE", "load": 9},
			{"name": "COMMs", "status": "DEGRADED", "load": 88},
		},
		"active_users": 1247,
		"city_population_status": map[string]int{
			"in_city":   3847291,
			"monitored": 2104831,
			"flagged":   847,
		},
	})
}

func getSession(r *http.Request) (Session, bool) {
	cookie, err := r.Cookie("ctos_session")
	if err != nil {
		return Session{}, false
	}

	sessionsMu.RLock()
	defer sessionsMu.RUnlock()

	session, ok := sessions[cookie.Value]
	return session, ok
}

func generateSessionID() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func generateUserID() string {
	b := make([]byte, 4)
	rand.Read(b)
	return fmt.Sprintf("CT-%X-%X-%X", b[0], b[1], b[2])
}

func getUserRole(username string) string {
	switch username {
	case "admin":
		return "SYSTEM_ADMINISTRATOR"
	case "operator":
		return "CONTROL_OPERATOR"
	default:
		return "AUTHORIZED_USER"
	}
}

func getUserClass(username string) string {
	switch username {
	case "admin":
		return "L5_SYSADMIN"
	case "operator":
		return "L3_OPERATOR"
	default:
		return "L2_PROVISIONAL"
	}
}

func cleanupSessions() {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for range ticker.C {
		now := time.Now()
		sessionsMu.Lock()
		for id, session := range sessions {
			if now.Sub(session.CreatedAt) > 24*time.Hour {
				delete(sessions, id)
			}
		}
		sessionsMu.Unlock()
	}
}
