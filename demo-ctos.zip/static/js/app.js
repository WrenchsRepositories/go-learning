(() => {
  // ============================================================
  //  ctOS Login Page Interactions
  // ============================================================

  const $ = (s, c = document) => c.querySelector(s);

  // --- Boot sequence ---
  const bootEl = $("#bootSequence");
  const loginContainer = $("#loginContainer");
  const bootLines = [...document.querySelectorAll(".boot-line")];

  let bootIdx = 0;
  const nextBoot = () => {
    if (bootIdx >= bootLines.length) {
      setTimeout(() => {
        bootEl.classList.add("done");
        loginContainer.style.opacity = "1";
        startLiveStream();
        clockTick();
      }, 350);
      return;
    }
    const line = bootLines[bootIdx];
    const text = line.dataset.text || "";
    line.classList.add("visible");
    let ci = 0;
    const typeChar = () => {
      if (ci <= text.length) {
        // done
        bootIdx++;
        setTimeout(nextBoot, 120 + Math.random() * 140);
        return;
      }
      ci++;
      requestAnimationFrame(typeChar);
    };
    line.textContent = text;
    typeChar();
  };
  setTimeout(nextBoot, 300);

  // --- Status stream ---
  const streamContainer = $("#streamLines");
  const streamEvents = [
    { t: "[SURV]",   lvl: "ok",   m: "Camera mesh heartbeat OK (12,487 nodes)" },
    { t: "[AUTH]",   lvl: "info", m: "PAM module loaded: pam_unix.so" },
    { t: "[TRAFFIC]",lvl: "ok",   m: "Intersection timing sync complete" },
    { t: "[NET]",    lvl: "info", m: "Secure backhaul latency 3.1ms" },
    { t: "[POWER]",  lvl: "ok",   m: "Grid telemetry: phase balanced" },
    { t: "[SURV]",   lvl: "warn", m: "CAM-8812: tamper signature flagged" },
    { t: "[COMMS]",  lvl: "warn", m: "Tower #14 packet loss 0.8% (threshold)" },
    { t: "[AUTH]",   lvl: "info", m: "Listening for credentials on /api/login" },
    { t: "[WATER]",  lvl: "ok",   m: "District 7 variance within tolerance" },
    { t: "[CITY]",   lvl: "info", m: "Census scan: 3,847,291 in-city citizens" },
    { t: "[SURV]",   lvl: "ok",   m: "Facial recog vector DB loaded OK" },
    { t: "[AUTH]",   lvl: "info", m: "Operator credentials requested..." },
  ];

  let streamIdx = 0;
  function pushStream() {
    const ev = streamEvents[streamIdx % streamEvents.length];
    streamIdx++;
    const line = document.createElement("div");
    line.className = "stream-line";
    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    line.innerHTML = `<span class="sl-time">${ts}</span><span class="sl-tag ${ev.lvl}">${ev.t}</span>${ev.m}`;
    streamContainer.appendChild(line);
    while (streamContainer.children.length > 60) {
      streamContainer.removeChild(streamContainer.firstChild);
    }
    streamContainer.scrollTop = streamContainer.scrollHeight;
  }
  function startLiveStream() {
    for (let i = 0; i < 5; i++) setTimeout(pushStream, i * 220);
    // Reduced from 2200ms -> 3800ms to cut CPU/interrupt rate in half
    setInterval(pushStream, 3800);
  }

  // --- Clock ---
  function clockTick() {
    const el = $("#clock");
    if (!el) return;
    const update = () => {
      const d = new Date();
      const hh = String(d.getHours()).padStart(2, "0");
      const mm = String(d.getMinutes()).padStart(2, "0");
      const ss = String(d.getSeconds()).padStart(2, "0");
      el.textContent = `${hh}:${mm}:${ss} CT`;
    };
    update();
    setInterval(update, 1000);
  }

  // --- Identity card dynamic fields ---
  const FAKE_IDS = [
    { id: "CT-F24-118A", cls: "L3_OPERATOR",  name: "CONSOLE_OP",  role: "Control Operator" },
    { id: "CT-A11-0047", cls: "L5_SYSADMIN",  name: "ROOT_CTOS",   role: "System Admin" },
    { id: "CT-982-BB09", cls: "L2_PROVISIONAL", name: "TEMP_USER", role: "Provisional" },
    { id: "CT-3C4-8D21", cls: "L4_MANAGER",   name: "SHIFT_LEAD",  role: "Shift Lead" },
  ];
  let fakeIdx = 0;
  // Idle, lower-priority DOM update; lowered rate from 4500 -> 9000
  setInterval(() => {
    fakeIdx = (fakeIdx + 1) % FAKE_IDS.length;
    const f = FAKE_IDS[fakeIdx];
    const idF = $("#idField");
    const clsF = $("#classField");
    // If user is already typing, leave alone
    if (idF && !idF.classList.contains("locked")) {
      idF.textContent = f.id;
      clsF.textContent = f.cls;
    }
  }, 9000);

  // --- Login form ---
  const form = $("#loginForm");
  const msg = $("#authMessage");
  const btn = $("#submitBtn");
  const usernameEl = $("#username");
  const passwordEl = $("#password");

  function setMsg(text, kind = "info") {
    msg.className = `auth-message ${kind}`;
    msg.textContent = text;
  }

  function lockIdentity(res) {
    const idF = $("#idField");
    const clsF = $("#classField");
    const nmF = $("#nameField");
    const rlF = $("#roleField");
    if (idF) { idF.textContent = res.user.id; idF.classList.add("locked"); }
    if (clsF) clsF.textContent = res.user.class;
    if (nmF) nmF.textContent = res.user.username.toUpperCase();
    if (rlF) rlF.textContent = res.user.role;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = usernameEl.value.trim();
    const password = passwordEl.value;
    if (!username || !password) {
      setMsg("ERR: Both USERNAME and PASSWORD are required.", "error");
      return;
    }
    btn.disabled = true;
    setMsg(`Authenticating ${username} against ctOS PAM...`, "info");
    try {
      const r = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await r.json();
      if (!r.ok || !data.success) {
        setMsg(`[${data.error || "AUTH_FAILED"}] ${data.message || "Credentials rejected."}`, "error");
        passwordEl.value = "";
        passwordEl.focus();
        btn.disabled = false;
        return;
      }
      setMsg(`OK: Identity verified. Welcome, ${username}. Redirecting...`, "success");
      lockIdentity(data);
      setTimeout(() => { window.location.href = data.redirect || "/dashboard"; }, 900);
    } catch (err) {
      setMsg(`ERR: Network or transport failure - ${err.message}`, "error");
      btn.disabled = false;
    }
  });

  // Enter key convenience already handled by form submit
  usernameEl.addEventListener("keydown", (e) => {
    if (e.key === "Tab") { /* let default */ }
  });
})();
