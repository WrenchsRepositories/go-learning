(() => {
  // ============================================================
  //  ctOS Dashboard Interactions
  // ============================================================
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));

  // --- Clock ---
  function dashClock() {
    const el = $("#dashClock");
    const update = () => {
      const d = new Date();
      const hh = String(d.getHours()).padStart(2, "0");
      const mm = String(d.getMinutes()).padStart(2, "0");
      const ss = String(d.getSeconds()).padStart(2, "0");
      if (el) el.textContent = `${hh}:${mm}:${ss} CT`;
    };
    update();
    setInterval(update, 1000);
  }
  dashClock();

  // --- Navigation ---
  const navItems = $$(".nav-item");
  const views = $$(".view-panel");
  const titles = {
    overview:     ["CITY OVERVIEW",        "Chicago Metropolitan Cluster // Operational"],
    surveillance: ["SURVEILLANCE MESH",    "12,487 nodes // Full coverage except 1 alert"],
    traffic:      ["TRAFFIC CONTROL",      "1,842 intersections // 7 active incidents"],
    power:        ["POWER GRID CONTROL",   "38 substations // Load nominal 62%"],
    citizens:     ["CITIZEN DATABASE",     "3,847,291 profiles // Monitored: 2.1M"],
    logs:         ["AUDIT LOG",            "Full chain-of-custody // last 1000 events"],
  };
  const crumbEl = $("#crumbView");
  const titleMainEl = $("#viewTitle");
  const titleSubEl = $(".title-sub");

  navItems.forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.view;
      navItems.forEach(b => b.classList.toggle("active", b === btn));
      views.forEach(v => v.classList.toggle("hidden", v.id !== `view-${key}`));
      if (crumbEl) crumbEl.textContent = key;
      if (titles[key] && titleMainEl && titleSubEl) {
        titleMainEl.textContent = titles[key][0];
        titleSubEl.textContent = titles[key][1];
      }
    });
  });

  // --- Logout ---
  $("#logoutBtn").addEventListener("click", async () => {
    await fetch("/api/logout", { method: "POST" });
    window.location.href = "/login";
  });

  // --- Services table (from /api/status) ---
  const svcTbody = $("#svcTbody");
  function renderServices(list) {
    if (!svcTbody) return;
    svcTbody.innerHTML = "";
    list.forEach(s => {
      const tr = document.createElement("tr");
      const statusClass = s.status === "ONLINE" ? "online" : (s.status === "DEGRADED" ? "degraded" : "offline");
      const healthClass = s.load >= 85 ? "crit" : (s.load >= 60 ? "warn" : "ok");
      const healthText  = s.load >= 85 ? "HIGH" : (s.load >= 60 ? "MED" : "OK");
      tr.innerHTML = `
        <td>${s.name}</td>
        <td class="svc-status ${statusClass}">${s.status}</td>
        <td><span class="svc-load-bar"><span class="svc-load-fill" style="width:${s.load}%"></span></span>${s.load}%</td>
        <td class="svc-health ${healthClass}">${healthText}</td>`;
      svcTbody.appendChild(tr);
    });
  }

  async function refreshStatus() {
    try {
      const r = await fetch("/api/status");
      if (!r.ok) return;
      const d = await r.json();
      renderServices(d.services || []);
      if ($("#mPopIn"))  $("#mPopIn").textContent  = Number(d.city_population_status?.in_city || 0).toLocaleString();
      if ($("#mMon"))    $("#mMon").textContent    = Number(d.city_population_status?.monitored || 0).toLocaleString();
      if ($("#mFlag"))   $("#mFlag").textContent   = Number(d.city_population_status?.flagged || 0).toLocaleString();
    } catch (e) { /* noop */ }
  }
  refreshStatus();
  $("#refreshServices")?.addEventListener("click", refreshStatus);
  // Reduced backend poll from 15s -> 30s
  setInterval(refreshStatus, 30000);

  // --- Activity stream ---
  const activityTmpl = [
    { t: "SURV", lvl: "ok",   m: "Face match on 5th Ave crosswalk camera" },
    { t: "TRAFFIC", lvl: "info", m: "Adaptive timing applied to State/Orleans" },
    { t: "AUTH", lvl: "info", m: `Session refresh for ${getUser()}` },
    { t: "COMMS", lvl: "warn", m: "Microwave link #14 retransmits elevated" },
    { t: "SURV", lvl: "crit", m: "Camera 8812 tamper signature persists" },
    { t: "POWER", lvl: "ok", m: "Substation #9 load tap changer cycled" },
    { t: "WATER", lvl: "ok", m: "District 7 pressure within tolerance" },
    { t: "CITY", lvl: "info", m: "Census micro-scan complete (12,400 profiles)" },
    { t: "TRAFFIC", lvl: "warn", m: "Stevenson Expy avg speed below 15 mph" },
    { t: "AUTH", lvl: "ok", m: "MFA challenge satisfied for admin" },
    { t: "SURV", lvl: "info", m: "Camera mesh frame-buffer sync OK" },
    { t: "COMMS", lvl: "info", m: "Cell tower handover batch complete (1,204 UE)" },
  ];
  let actIdx = 0;
  function pushActivity(init = false) {
    const host = $("#activityStream");
    if (!host) return;
    const line = document.createElement("div");
    const e = activityTmpl[actIdx % activityTmpl.length];
    actIdx++;
    const d = new Date();
    const ts = `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}:${String(d.getSeconds()).padStart(2,"0")}`;
    line.className = "as-line";
    line.innerHTML = `<span class="as-time">${ts}</span><span class="as-tag ${e.lvl}">[${e.t}]</span><span>${e.m}</span>`;
    host.appendChild(line);
    while (host.children.length > (init ? 30 : 120)) host.removeChild(host.firstChild);
    host.scrollTop = host.scrollHeight;
  }
  for (let i = 0; i < 14; i++) pushActivity(true);
  // Slowed from 1800ms -> 3500ms; avoids per-second DOM churn
  setInterval(pushActivity, 3500);

  // --- Audit log ---
  const auditHost = $("#auditLog");
  function pushAudit() {
    if (!auditHost) return;
    const users = ["admin", "operator", "ctos", "shift.supervisor", "audit.svc"];
    const actions = [
      "QUERY citizen.profile by ID",
      "VIEW camera #8812 live feed",
      "MODIFY traffic timing pattern 0x7",
      "ACK alert [SURV-778]",
      "EXPORT csv: flagged-persons-today",
      "LOGIN successful",
      "LOGOUT session ended",
      "READ power-grid telemetry",
      "SUBSCRIBE activity stream",
      "OVERRIDE substation #14 breaker state",
    ];
    const u = users[Math.floor(Math.random()*users.length)];
    const a = actions[Math.floor(Math.random()*actions.length)];
    const d = new Date();
    const ts = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}:${String(d.getSeconds()).padStart(2,"0")}`;
    const src = `10.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
    const line = document.createElement("div");
    line.innerHTML = `<span style="color:var(--ink-faint)">${ts}</span> <span style="color:var(--accent-3)">${u}</span> <span style="color:var(--ink-dim)">@</span> <span style="color:var(--accent)">${src}</span>  <span style="color:var(--ink)">${a}</span>`;
    auditHost.appendChild(line);
    while (auditHost.children.length > 120) auditHost.removeChild(auditHost.firstChild);
    auditHost.scrollTop = auditHost.scrollHeight;
  }
  for (let i = 0; i < 20; i++) pushAudit();
  // Slowed from 3200ms -> 6500ms
  setInterval(pushAudit, 6500);

  // --- Helpers ---
  function getUser() {
    const n = $(".su-name");
    return n ? n.textContent : "operator";
  }
})();
