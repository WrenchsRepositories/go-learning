module ctos-web

go 1.22
